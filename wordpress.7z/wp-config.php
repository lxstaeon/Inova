<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'mysite' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'admin' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', 'basisol40@' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '>9?[.}VcT?FGw` w;pJ^Tuno^oi)#|Tnh$OSy/EW*^V~{Y;`D*CU-n?7cQ2*.(-^' );
define( 'SECURE_AUTH_KEY',  '}WPI2M=p$zhu8r]#Gw8q5?(sN%8%8aTecboGc]w9h ZKYr!h`5c[LEw]Jy))Z5MC' );
define( 'LOGGED_IN_KEY',    ':77>m`svQ@|K(9LezO!>AF~8p.6 Fyok5$;0/RbB+GHv3N%:?Hf/NAw6?5}DT&v6' );
define( 'NONCE_KEY',        '[6*;+P;W_SZkHKl_~ceL,DzRGR.M0R5g2I{Nb/$7z`XgR&o+q_](S)p1L8Bn]o?%' );
define( 'AUTH_SALT',        'w9B9xsBs}dIzi18l,~J/;EU/nEAV+&sZpQP!+3;Z-[,c2yLVe9Yk1jgmtlPEx#0~' );
define( 'SECURE_AUTH_SALT', '%0O<D)&=Cud-hnQEMip+}$vs/gDOw>X/-AJ{f!j!El_wh[fM7w0njUAjy)5?wXqs' );
define( 'LOGGED_IN_SALT',   'U}%OMmpy<XA_fx&yOb$IkU8CzRTvPn+X5* (yrB)1Gp;-1Fbuy)b7)POwm)R|ff*' );
define( 'NONCE_SALT',       'O-n V-IF3B*&n5T&_L%(1(,##e:Egd>L:|X$/>#G,hp5 Xdl`?.O;&~[*U3t7UnT' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
